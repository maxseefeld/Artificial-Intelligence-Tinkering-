# Javascript
I have no fucking clue how to do persistence deal with it
